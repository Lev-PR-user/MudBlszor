﻿namespace BlazorApp1.Models
{
    public class ThemeManagerModel
    {
        public bool IsDarkMode { get; set; }
        public string PrimaryColor { get; set; }
    }
}
